package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    @GetMapping("/hash")
    public String displayHash() {
        String data = "checksum test data";
        String checksum = generateSHA256Hash(data);

        return "<html><body style='font-family:Arial;padding:20px;'>"
                + "<h2>Artemis Financial Secure Communications</h2>"
                + "<p><b>Name:</b> Hamza Y</p>"
                + "<p><b>Data:</b> " + data + "</p>"
                + "<p><b>SHA-256:</b> " + checksum + "</p>"
                + "</body></html>";
    }

    private String generateSHA256Hash(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));

            StringBuilder hex = new StringBuilder();

            for (byte b : hash) {
                String h = Integer.toHexString(0xff & b);
                if (h.length() == 1) hex.append('0');
                hex.append(h);
            }

            return hex.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";